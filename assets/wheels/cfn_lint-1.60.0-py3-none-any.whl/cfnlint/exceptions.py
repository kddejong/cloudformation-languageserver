"""
Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cfnlint.config import ConfigMixIn


class CfnLintExitException(Exception):
    """
    An exception that is raised to indicate that the CloudFormation linter should exit.

    This exception is used to signal that the linter should exit
    with a specific exit code, typically indicating the severity
    of the issues found in the CloudFormation template.

    Attributes:
        exit_code (int): The exit code to be used when the linter exits.

    Methods:
        __init__(self, msg: str | None=None, exit_code: int=1) -> None:
            Initialize a new CfnLintExitException instance with the specified exit code.
    """

    def __init__(self, msg: str | None = None, exit_code: int = 1):
        """
        Initialize a new CfnLintExitException instance with the specified exit code.

        Args:
            exit_code (int): The exit code to be used when the linter exits.
        """
        if msg is None:
            msg = f"process failed with exit code {exit_code}"
        super().__init__(msg)
        self.exit_code = exit_code


class InvalidRegionException(CfnLintExitException):
    """
    An exception that is raised when an invalid AWS region is encountered.

    This exception is raised when the CloudFormation linter encounters a resource
    or parameter that references an AWS region that is not valid or supported.
    """


class UnexpectedRuleException(CfnLintExitException):
    """
    An exception that is raised when an unexpected error occurs while loading rules.

    This exception is raised when the CloudFormation linter encounters an error
    while attempting to load custom rules or rules from a specified directory or
    module. This could be due to a variety of reasons, such as a missing file,
    a syntax error in the rule code, or an issue with the rule implementation.
    """


class DuplicateRuleError(CfnLintExitException):
    """
    An exception that is raised when an unexpected error occurs while loading rules.

    This exception is raised when the CloudFormation linter encounters a rule with a
    duplicate ID.
    """

    def __init__(self, rule_id: str):
        """
        Initialize a new CfnLintExitException instance with the specified exit code.

        Args:
            rule_id (str): The rule ID that a duplicate was found for.
        """
        super().__init__(f"Rule already included: {rule_id}")


class ConfigFileError(CfnLintExitException):
    """
    An exception that is raised when there is an error in the configuration file.

    This exception is raised when the CloudFormation linter encounters an error
    while parsing or validating the .cfnlintrc configuration file.
    """

    def __init__(self, msg: str, config: ConfigMixIn):
        """
        Initialize a new ConfigFileError instance.

        Args:
            msg (str): The error message
            config (ConfigMixIn): A minimal config for formatting
        """
        super().__init__(msg)
        self.config = config


class SchemaPatchError(CfnLintExitException):
    """
    An exception that is raised when an override spec cannot be read or a JSON
    patch in it cannot be applied to the schema it names.
    """


class TemplatesNotFoundError(CfnLintExitException):
    """
    An exception that is raised when the configured templates cannot be resolved.

    This exception is raised when a template path or glob given to the linter
    matches no files. The CLI reports this as an error level match, so the exit
    code is 2 rather than the default of 1.
    """

    def __init__(self, msg: str):
        """
        Initialize a new TemplatesNotFoundError instance.

        Args:
            msg (str): The error message
        """
        super().__init__(msg, 2)
